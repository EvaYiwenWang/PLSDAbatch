library(testthat)
library(PLSDAbatch)

test_check("PLSDAbatch")
