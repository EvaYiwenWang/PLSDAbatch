## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(dpi = 300, echo = TRUE, warning = FALSE, message = FALSE, 
                    eval = TRUE, fig.show = TRUE, fig.width = 6, 
                    fig.height = 4, fig.align ='center', 
                    out.width = '60%', cache = FALSE)

## ---- include = FALSE---------------------------------------------------------
colorize <- function(x, color){
    if(knitr::is_latex_output()){
        sprintf("\\textcolor{%s}{%s}", color, x)
    }else if(knitr::is_html_output()){
        htmlcolor = "black"
        if(color == "blue"){
            htmlcolor = "#0000FF"
        }
        if(color == "brown"){
            htmlcolor = "#964B00"
        }
        if(color == "olive"){
            htmlcolor = "#808000"
        }
        if(color == "violet"){
            htmlcolor = "#8601AF"
        }
        if(color == "orange"){
            htmlcolor = "#FF7F00"
        }
        sprintf("<span style='color: %s;'>%s</span>", htmlcolor, x)
    }else x
}

## -----------------------------------------------------------------------------
# Bioconductor
bioc.pkgs <- c('mixOmics', 'Biobase')
# GitHub
github.pkg <- 'PLSDAbatch' 
# devtools::install_github("https://github.com/EvaYiwenWang/PLSDAbatch")

# load packages 
sapply(c(bioc.pkgs, github.pkg), require, character.only = TRUE)

# print package versions
sapply(c(bioc.pkgs, github.pkg), package.version)

## -----------------------------------------------------------------------------
# AD data
data('AD_data') 
ad.count <- AD_data$FullData$X.count
dim(ad.count)

ad.metadata <- AD_data$FullData$metadata
ad.batch = factor(ad.metadata$sequencing_run_date, 
                levels = unique(ad.metadata$sequencing_run_date))
ad.trt = as.factor(ad.metadata$initial_phenol_concentration.regroup)
names(ad.batch) <- names(ad.trt) <- rownames(ad.metadata)

## -----------------------------------------------------------------------------
ad.filter.res <- PreFL(data = ad.count)
ad.filter <- ad.filter.res$data.filter
dim(ad.filter)

# zero proportion before filtering
ad.filter.res$zero.prob
# zero proportion after filtering
sum(ad.filter == 0)/(nrow(ad.filter) * ncol(ad.filter))

## -----------------------------------------------------------------------------
ad.clr <- logratio.transfo(X = ad.filter, logratio = 'CLR', offset = 1) 
class(ad.clr) = 'matrix'

## -----------------------------------------------------------------------------
# estimate the number of treatment components
ad.trt.tune <- plsda(X = ad.clr, Y = ad.trt, ncomp = 5)
ad.trt.tune$prop_expl_var #1

## -----------------------------------------------------------------------------
# estimate the number of batch components
ad.batch.tune <- PLSDA_batch(X = ad.clr, 
                            Y.trt = ad.trt, Y.bat = ad.batch,
                            ncomp.trt = 1, ncomp.bat = 10)
ad.batch.tune$explained_variance.bat #4
sum(ad.batch.tune$explained_variance.bat$Y[seq_len(4)])


## -----------------------------------------------------------------------------
ad.PLSDA_batch.res <- PLSDA_batch(X = ad.clr, 
                                Y.trt = ad.trt, Y.bat = ad.batch,
                                ncomp.trt = 1, ncomp.bat = 4)
ad.PLSDA_batch <- ad.PLSDA_batch.res$X.nobatch

## ---- eval = F----------------------------------------------------------------
#  # estimate the number of variables to select per treatment component
#  set.seed(777)
#  ad.test.keepX = c(seq(1, 10, 1), seq(20, 100, 10),
#                  seq(150, 231, 50), 231)
#  ad.trt.tune.v <- tune.splsda(X = ad.clr, Y = ad.trt,
#                              ncomp = 1, test.keepX = ad.test.keepX,
#                              validation = 'Mfold', folds = 4,
#                              nrepeat = 50)
#  ad.trt.tune.v$choice.keepX #100
#  

## -----------------------------------------------------------------------------
# estimate the number of batch components
ad.batch.tune <- PLSDA_batch(X = ad.clr, 
                            Y.trt = ad.trt, Y.bat = ad.batch,
                            ncomp.trt = 1, keepX.trt = 100,
                            ncomp.bat = 10)
ad.batch.tune$explained_variance.bat #4
sum(ad.batch.tune$explained_variance.bat$Y[seq_len(4)])

## -----------------------------------------------------------------------------
ad.sPLSDA_batch.res <- PLSDA_batch(X = ad.clr, 
                                Y.trt = ad.trt, Y.bat = ad.batch,
                                ncomp.trt = 1, keepX.trt = 100,
                                ncomp.bat = 4)
ad.sPLSDA_batch <- ad.sPLSDA_batch.res$X.nobatch

## -----------------------------------------------------------------------------
splsda.plsda_batch <- splsda(X = ad.PLSDA_batch, Y = ad.trt, 
                            ncomp = 3, keepX = rep(50,3))
select.plsda_batch <- selectVar(splsda.plsda_batch, comp = 1)
head(select.plsda_batch$value)

splsda.splsda_batch <- splsda(X = ad.sPLSDA_batch, Y = ad.trt, 
                            ncomp = 3, keepX = rep(50,3))
select.splsda_batch <- selectVar(splsda.splsda_batch, comp = 1)
head(select.splsda_batch$value)

length(intersect(select.plsda_batch$name, select.splsda_batch$name))

## -----------------------------------------------------------------------------
sessionInfo()

